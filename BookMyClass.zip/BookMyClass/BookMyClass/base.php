<span style="font-family: verdana, geneva, sans-serif;"><!DOCTYPE html>
    <html lang="en">
    <head>
      <title>BookMyClass</title>
      <link rel="stylesheet" href="css\style1.css" />
      <link href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/5.10.1/main.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/5.10.1/main.min.js"></script>
<link href='https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/5.10.1/main.min.css' rel='stylesheet' />
    <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js'></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js'></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/5.10.1/main.min.js'></script>

      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" />
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Noto+Sans+HK&amp;display=swap'><link rel="stylesheet" href="./style.css">
<script src="schedulingsystem\dashboard\clock.js"></script>
    </head>
    <body>
      <div class="container">
        <nav>
          <div class="navbar">
            <div class="logo">
              <img src="https://imgs.search.brave.com/o3IcelnQUf3BBFB5HklInU2eKn5eiSUp5opScoZxxsY/rs:fit:860:0:0/g:ce/aHR0cHM6Ly9nY3Nv/bmxpbmUuY28uaW4v/dXBsb2FkL2ltZy8y/MDIzMDIyNjIxMDUw/NS5wbmc" alt="image" width="25" height="40">
              
            </div>
            <ul>
              
              
              <li><a href="home.php">
              <i class="fas fa-user"></i>
                
                <span class="nav-item">BookMyClass</span>
              </a>
              </li>
              <li><a href="EmployeeAttendance_CI">
              <i class="fas fa-tasks"></i>
                
                <span class="nav-item">Attendance</span>
              </a>
              </li>
              <li><a href="tablelist.php">
              <i class="fab fa-dochub"></i>
                <span class="nav-item">Schedule</span>
              </a>
              </li>
              <li><a href="list.php">
                <i class="fas fa-cog"></i>
                <span class="nav-item">Setting</span>
              </a>
              </li>
             
              <li><a href="home1.php" class="logout">
                <i class="fas fa-sign-out-alt"></i>
                <span class="nav-item">Logout</span>
              </a>
              </li>
            </ul>
          </div>
        </nav>
      </div>
      <div class="img-banner">
        <img src="https://i.pinimg.com/564x/2c/77/e3/2c77e3e0b91dd5f4c07bb8dcf09b223e.jpg" alt="img-wallpaper" srcset="">
    </div>
      
     <div class="calendar">
        <div class="header">
            <button id="prevBtn">
                <i class="fas fa-chevron-left"></i>
            </button>
            <div class="monthYear" id="monthYear"></div> 
            <button id="nextBtn">
                <i class="fas fa-chevron-right"></i>
            </button>
           
        </div>
       
        <div class="days">
            <div class="day">Mon</div>
            <div class="day">Tue</div>
            <div class="day">Wed</div>
            <div class="day">Thu</div>
            <div class="day">Fri</div>
            <div class="day">Sat</div>
            <div class="day">Sun</div>
        </div>
        <div class="dates" id="dates"></div>
    </div>
    <script src="dashboard\base.js"></script>
  

    
<section class="todoapp">
  <header class="header1">
    <input class="new-todo"
        autocomplete="off"
        placeholder="Type your todo list"
        v-model="newTodo"
        @keyup.enter="addTodo">
      <button class="new-todo-button"
        @click="addTodo"  
        v-show="newTodo.length > 0"
      ></button>
  </header>
  <section class="main" v-show="todos.length" v-cloak>
    <div class="completed-wrapper">
      <input id="toggle-all" class="toggle-all" type="checkbox" v-model="allDone">
      <label for="toggle-all">Complete all tasks</label>
      <button class="clear-completed" @click="removeCompleted">
        Clear completed
      </button>
    </div>
    <ul class="todo-list">
      <li v-for="todo in filteredTodos"
        class="todo"
        :key="todo.id"
        :class="{ completed: todo.completed, editing: todo == editedTodo }">
        <div class="view">
          <input class="toggle" type="checkbox" v-model="todo.completed">
          <label @dblclick="editTodo(todo)">{{ todo.title }}</label>
          <button class="destroy" @click="removeTodo(todo)"></button>
        </div>
        <input class="edit" type="text"
          v-model="todo.title"
          v-todo-focus="todo == editedTodo"
          @blur="doneEdit(todo)"
          @keyup.enter="doneEdit(todo)"
          @keyup.esc="cancelEdit(todo)">
      </li>
    </ul>
  </section>
  <footer class="footer" v-show="todos.length" v-cloak>
    <span class="todo-count">
      <strong>{{ remaining }}</strong> {{ remaining | pluralize }} left
    </span>
    <ul class="filters">
      <li><a href="#/all" :class="{ selected: visibility == 'all' }">All</a></li>
      <li><a href="#/active" :class="{ selected: visibility == 'active' }">Uncomplete</a></li>
      <li><a href="#/completed" :class="{ selected: visibility == 'completed' }">Completed</a></li>
    </ul>
  </footer>
</section>

  <script src='https://cdnjs.cloudflare.com/ajax/libs/vue/2.6.10/vue.min.js'></script>
  <script  src="dashboard\todo.js"></script>
  
  </span>
 
    </html>