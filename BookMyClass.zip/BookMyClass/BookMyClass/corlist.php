<?php
include_once("header.php");
include_once("navbar.php");

// Database configuration
$host = "localhost";
$username = "root";
$password = "";
$database = "insertion";

// Connect to MySQL database
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Delete record if POST request is made
if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['course_id'])) {
    $course_id = $conn->real_escape_string($_POST['course_id']);
    $sql = "DELETE FROM course WHERE course_id='$course_id'";
    if ($conn->query($sql) === TRUE) {
        echo '<script type="text/javascript">
                      alert("Schedule Successfully Deleted");
                      window.location.href = "list.php";
              </script>';
    } else {
        echo "Error deleting record: " . $conn->error;
    }
}

// Fetch data from database
$query = "SELECT * FROM course";
$result = $conn->query($query);

echo '<div class="container">';
echo '<table class="table table-bordered">';
echo '<thead>';
echo '<tr>';
echo '<th>Code</th>';
echo '<th>Course</th>';
echo '<th>Action</th>';
echo '</tr>';
echo '</thead>';
echo '<tbody>';

// Display fetched data
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo '<tr>';
        echo '<td>' . $row['course_code'] . '</td>';
        echo '<td>' . $row['course_name'] . '</td>';
        echo '<td>
                <form class="form-horizontal" method="post" action="corlist.php">
                    <input name="course_id" type="hidden" value="' . $row['course_id'] . '">
                    <input type="submit" class="btn btn-danger" name="delete" value="Delete">
                </form>
              </td>';
        echo '</tr>';
    }
} else {
    echo '<tr><td colspan="3">No records found</td></tr>';
}

echo '</tbody>';
echo '</table>';
echo '</div>';

$conn->close(); // Close database connection

include_once("footer.php");
?>
