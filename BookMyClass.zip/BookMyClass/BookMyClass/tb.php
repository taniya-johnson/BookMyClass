<?php
include_once("header.php");
include_once("navbar.php");
?>

<html>
<head>
    <style>
        body {
            background-color: white;
        }
        
        tr:hover,
        tr.alt:hover {
            background: #f7dcdf;
        }
    </style>
</head>
<body>
    <div id="content">
        <div id="form">
            <fieldset>
                <legend>Schedules</legend>
                <?php
                echo "<table class='table' width='99.120%' border='0'>
                        <tr class='table'>
                            <th>Name</th>
                            <th>Course</th>
                            <th>Subject</th>
                            <th>Room</th>
                            <th>Start Time</th>
                            <th>End Time</th>
                            <th>Action</th>
                        </tr>";

                // your database connection
                $host = "localhost";
                $username = "root";
                $password = "";
                $database = "insertion";

                // Create connection
                $conn = new mysqli($host, $username, $password, $database);
                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                $query = "SELECT * FROM data";
                $result = $conn->query($query);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row['name'] . "</td>";
                        echo "<td>" . $row['subject'] . "</td>";
                        echo "<td>" . $row['room'] . "</td>";
                        echo "<td>" . $row['startTime'] . "</td>";
                        echo "<td>" . $row['endTime'] . "</td>";
                        echo "<td>
                                <form method='post' action='tb.php'>
                                    <input name='id' type='hidden' value='" . $row['id'] . "'>
                                    <input type='submit' name='submit' value='Delete'>
                                </form>
                              </td>";
                        echo "</tr>";
                    }
                }
                echo "</table>";

                // delete record
                if ($_SERVER['REQUEST_METHOD'] == "POST") {
                    echo '<script type="text/javascript">
                              alert("Schedule Successfully Deleted");
                              location="tb.php";
                          </script>';
                }
                if (isset($_POST['id'])) {
                    $id = $conn->real_escape_string($_POST['id']);
                    $sql = "DELETE FROM data WHERE id='$id'";
                    if ($conn->query($sql) === FALSE) {
                        echo "Could not delete rows" . $conn->error;
                    }
                }
                ?>
            </fieldset>
        </div>
    </div>
    <div align="center">
        <br>
        <a href="Insertion.php"><input type='submit' class='' name='delete' value='New'></a>
        <a href="Index.php"><input type='submit' class='' name='delete' value='Logout'></a>
    </div>
</body>
</html>

<?php
$path = $_SERVER['DOCUMENT_ROOT'];
$path .= "footer.php";
include_once("footer.php");
?>
