<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <a href="home.html" ><img src="https://www.sju.edu.in/images/logo.png" alt="college-logo" id="head-logo"></a>
        <a href="home1.php">Home</a>
    <a href="about.php">About Us</a>
    <a href="https://sju.edu.in/">Info</a>
    <a href="index.php">Portal</a>
    </header>
     
   
    </div>
    <div class="img-banner">
        <img src="https://sju.edu.in/uploads/banners/banner/897718251_2024-04-02_03-28-36.webp" alt="img-wallpaper" srcset="">
    </div>
    <!-- Welcome Section -->
    <section id="progrmm-serch-item">
  <div class="container">
        	<div class="welcm-tt">
    	<div class="common-heading_1">
          <h1> <span> Welcome to </span>St Joseph’s University,  Bengaluru, India</h1>
          
        </div>
       <p style="text-align:justify">St Joseph&rsquo;s University is a Jesuit university at the heart of Bengaluru, the silicon city of India. Established in 1882 by Paris Foreign Mission Fathers, the management of the college was handed over to the Jesuit order (Society of Jesus) in 1937. The college was first affiliated with the University of Madras and later with the Mysore and Bangalore universities. In 1986, St Joseph&rsquo;s College became the first affiliated college in Karnataka to offer postgraduate programmes. In 1988, it became the first college in Karnataka to get a Research Centre, and in 2005, it was one of five colleges in Karnataka that was awarded academic autonomy. In February 2021, St Joseph&#39;s University Bill was presented in the Karnataka Legislative Assembly and was subsequently passed by the Legislative Assembly and Karnataka Legislative Councill. The college received its University status on 2 July 2022 and was&nbsp;<strong>inaugurated as India&rsquo;s first Public-Private-Partnership University&nbsp;</strong>by the Honourable President of India, Smt. Droupadi Murmu on 27 September 2022.&nbsp;</p>

<p style="text-align:justify">&nbsp;</p>

<p style="text-align:justify">As a university, we are dedicated to excellence in education. Over the years, our students have been ranked among the finest in the country, as attested by our illustrious alumni. With an accomplished faculty both in teaching and research, the university is home to leading centres of excellence on campus. Here we try to create leaders for a better world, leaders deeply rooted in our philosophy &ldquo;<em>Fide et Labore</em>&rdquo; (a Latin phrase that means &quot;Faith and Toil&quot;), who commit themselves to excel in the fields they choose. We make every effort to be relevant, innovative, and creative. St Joseph&rsquo;s continues to be a place of deep care for each person, especially those who feel most vulnerable. Join us and be part of this glorious enterprise!</p>    </div>
          
  </div>
</section>
    
        
    </div>
    <footer>
        &copy; 2024 BookMyClass | All rights reserved | Developed by Taniya Johnson (21CMS12) and Steve Samson Chesney (21CMS43)
    </footer>
</body>
</html>