<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>About Us</title>
    
</head>
<style>
    header {
    height: fit-content;
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-evenly;
    padding: 5px;
    border-bottom: 2px solid black;
}

header a {
    font-size: large;
}

#head-logo{
    height:100px; 
    width:300px;
}
body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        footer {
            background-color: #f8f9fa;
            color: #333;
            text-align: center;
            padding: 5px 0;
            position: fixed;
            bottom: 0;
            width: 100%;
        }

        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 0 20px;
        }

        h1, h2 {
            color: #1c1249;
        }

        section {
            margin-bottom: 30px;
        }

        ul {
            list-style-type: none;
            padding-left: 0;
        }

        a {
            color: #1c1249;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }
</style>
<body>
    <header>
        <a href="home.html" ><img src="https://www.sju.edu.in/images/logo.png" alt="college-logo" id="head-logo"></a>
        <a href="home1.php">Home</a>
        <a href="about.php">About Us</a>
    <a href="https://sju.edu.in/">Info</a>
    <a href="index.php">Portal</a>
    </header>
    <div class="container">
        <section id="mission">
            <h2>Our Mission</h2>
            <p>At BookMyClass, our mission is to simplify the complexities of class management for educational institutions while enhancing the overall experience for students and faculty members. We strive to provide innovative solutions that streamline administrative tasks, improve efficiency, and promote student success.</p>
        </section>

        <section id="story">
            <h2>Our Story</h2>
            <p>Taniya and Steve, both passionate about leveraging technology to solve real-world challenges in education, came together to create BookMyClass during their time at St.Joseph's University. Faced with the inefficiencies of traditional class scheduling and attendance tracking methods, they recognized the need for a modern, user-friendly platform that could address these pain points.</p>
            <p>Driven by their shared vision of empowering educational institutions with cutting-edge technology, Taniya and Steve embarked on a journey to develop BookMyClass. With dedication, perseverance, and a commitment to excellence, they transformed their idea into a reality, culminating in the launch of BookMyClass.</p>
        </section>

        <section id="values">
            <h2>Our Values</h2>
            <ul>
                <li><strong>Innovation:</strong> We embrace innovation and continually strive to push the boundaries of what's possible in educational technology.</li></br>
                <li><strong>Accessibility:</strong> We believe that education should be accessible to all, and we design our solutions with inclusivity in mind.</li></br>
                <li><strong>Reliability:</strong> We are committed to providing reliable, high-quality software solutions that our users can trust.</li></br>
                <li><strong>Collaboration:</strong> We value collaboration and actively seek input from students, faculty, and administrators to improve our products.</li></br>
                <li><strong>Customer Success:</strong> We are dedicated to the success of our customers and go above and beyond to ensure they have a positive experience with BookMyClass.</li></br>
            </ul>
        </section>

        <section id="future">
            <h2>Our Future</h2>
            <p>As we look to the future, we remain committed to our mission of transforming class management in educational institutions. We will continue to innovate, iterate, and improve our products to meet the evolving needs of our users. Our goal is to become the leading provider of class management solutions, empowering educational institutions worldwide to achieve their goals.</p>
        </section>

        <section id="contact">
            <h2>Get in Touch</h2>
            <p>We'd love to hear from you! If you have any questions, feedback, or suggestions, please don't hesitate to reach out to us. You can contact us at <a href="mailto:info@bookmyclass.com">info@bookmyclass.com</a> or connect with us on social media <a href="#">@BookMyClass</a>.</p>
        </section>
    </div>
</body>
<footer>
        &copy; 2024 BookMyClass | All rights reserved | Developed by Taniya Johnson (21CMS12) and Steve Samson Chesney (21CMS43)
    </footer>
    
</body>
</html>
    

