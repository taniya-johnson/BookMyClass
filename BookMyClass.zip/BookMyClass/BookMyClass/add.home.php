<?php 

$con = mysqli_connect('localhost', 'root', '', 'insertion');
if (!$con) {
    die('Could not connect to server: ' . mysqli_connect_error());
}

function getPosts()
{
    $posts = array();
    $posts[0] = $_POST['faculty'];
    $posts[1] = $_POST['course'];
    $posts[2] = $_POST['subject'];
    $posts[3] = $_POST['room'];
    $posts[4] = $_POST['start_time'];
    $posts[5] = $_POST['end_time'];
    $posts[6] = $_POST['date'];
    return $posts;
}

if (isset($_POST['insert'])) {
    $data = getPosts();

    // Check if all necessary fields are set
    if (count($data) != 7) {
        die('Missing POST data');
    }

    // Use prepared statements to prevent SQL injection
   /* $existing_Query = "SELECT * FROM `addtable` WHERE `faculty`=? AND `course`=? AND `subject`=? AND `room`=? AND `start_time`=? AND `end_time`=? AND `date`=?";
    $stmt = mysqli_prepare($con, $existing_Query);
    mysqli_stmt_bind_param($stmt, "sssssss", $data[0], $data[1], $data[2], $data[3], $data[4], $data[5], $data[6]);
    mysqli_stmt_execute($stmt);
    $existing_Result = mysqli_stmt_get_result($stmt);

    if ($existing_Result !== false && mysqli_num_rows($existing_Result) > 0) {
        echo '<script type="text/javascript">
              alert("Your entry is already in the table/list. Please choose another schedule.");
              window.location="home.php";
              </script>';
    } else {*/
        // Check for conflicting bookings
        $conflict_query = "SELECT faculty FROM addtable WHERE room = ? AND ((start_time <= ? AND end_time >= ?) OR (start_time >= ? AND start_time < ?))";
        $stmt = mysqli_prepare($con, $conflict_query);
        mysqli_stmt_bind_param($stmt, "sssss", $data[3], $data[4], $data[4], $data[4], $data[5]);
        mysqli_stmt_execute($stmt);
        $conflict_result = mysqli_stmt_get_result($stmt);

        if (!($conflict_result && mysqli_num_rows($conflict_result)) > 0) {
            // Fetch the conflicting faculty names
            $conflicting_faculties = [];
            while ($row = mysqli_fetch_assoc($conflict_result)) {
                $conflicting_faculties[] = $row['faculty'];
            }

            // Print the names of the faculty who have booked the room during the same time slot
            echo "Room {$data[3]} is already occupied " . implode(', ', $conflicting_faculties);
        } else {
            // Insert new schedule
            $insert_Query = "INSERT INTO `addtable` (`faculty`, `course`, `subject`, `room`, `start_time`, `end_time`, `date`) VALUES (?, ?, ?, ?, ?, ?, ?)";
            $stmt = mysqli_prepare($con, $insert_Query);
            mysqli_stmt_bind_param($stmt, "sssssss", $data[0], $data[1], $data[2], $data[3], $data[4], $data[5], $data[6]);
            $insert_Result = mysqli_stmt_execute($stmt);

            if ($insert_Result) {
                echo "<script type='text/javascript'>
                      alert('New schedule added successfully');
                      window.location='tablelist.php';
                      </script>";
            } else {
                echo "<script type='text/javascript'>
                      alert('Data not inserted!');
                      window.location='home.php';
                      </script>";
            }
        }
    }
//}
?>
