<?php
include_once("header.php");
include_once("navbar.php");

// Database configuration
$host = "localhost";
$username = "root";
$password = "";
$database = "insertion";

// Connect to MySQL database
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Delete record if POST request is made
if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['subject_id'])) {
    $subject_id = $conn->real_escape_string($_POST['subject_id']);
    $sql = "DELETE FROM subject WHERE subject_id='$subject_id'";
    if ($conn->query($sql) === TRUE) {
        echo '<script type="text/javascript">
                      alert("Schedule Successfully Deleted");
                      window.location.href = "list.php";
              </script>';
    } else {
        echo "Error deleting record: " . $conn->error;
    }
}

// Fetch data from database
$query = "SELECT * FROM subject";
$result = $conn->query($query);

echo '<div class="container">';
echo '<table class="table table-bordered">';
echo '<thead>';
echo '<tr>';
echo '<th>Code</th>';
echo '<th>Subject</th>';
echo '<th>Action</th>';
echo '</tr>';
echo '</thead>';
echo '<tbody>';

// Display fetched data
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo '<tr>';
        echo '<td>' . $row['subject_code'] . '</td>';
        echo '<td>' . $row['subject_description'] . '</td>';
        echo '<td>
                <form class="form-horizontal" method="post" action="sublist.php">
                    <input name="subject_id" type="hidden" value="' . $row['subject_id'] . '">
                    <input type="submit" class="btn btn-danger" name="delete" value="Delete">
                </form>
              </td>';
        echo '</tr>';
    }
} else {
    echo '<tr><td colspan="3">No records found</td></tr>';
}

echo '</tbody>';
echo '</table>';
echo '</div>';

$conn->close(); // Close database connection

include_once("footer.php");
?>
