<?php
  $path = $_SERVER['DOCUMENT_ROOT'];
   $path .= "header.php";
   include_once("header.php");

?>

<html>
<head>
<style>

body {
	
	background-image: url(https://imgs.search.brave.com/f8lwXuAKo-jJJ2x_xCAtk9yNND2EpWHVgkFOQCaRMz8/rs:fit:860:0:0/g:ce/aHR0cHM6Ly93d3cu/aWVzb25saW5lLmNv/LmluL2NvbGxlZ2Vz/LWltYWdlL3N0LWpv/c2VwaC1hcnRzLXNj/aWVuY2UtY29sbGVn/ZS5qcGc);
	background-color: white;
	background-size: cover; /* Cover the entire container */
	background-position: center; /* Center the image */
	background-repeat: no-repeat; /* Do not repeat the image */
  
	/* Set the container size */
	width: 100%; /* Full width */
	height: 100vh; /* Full height of the viewport */
	/*background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,rgba(0,0,0,0)), color-stop(100%,rgba(0,0,0,0.65)));*/
	z-index: 1;
	opacity: 0.7;
}

</style>
</head>

<body>
	<nav class="navbar navbar-default navbar-static-top">
	  <div class="container">
	  <h3>REGISTRATION</h3>
	  </div>
	</nav>
	
	<div class="content">
		<div class="form">
		<form class="form-horizontal" method="post" action="regis.php">
			<fieldset>

			<legend>Add Account Here</legend>

			<br><div class="form-group">
			  <label class="col-md-4 control-label" for="username">Username</label>  
			  <div class="col-md-5">
			  <input id="username" name="username" type="text" placeholder="" class="form-control input-md" required="">
				
			  </div>
			</div>

			
			<div class="form-group">
			  <label class="col-md-4 control-label" for="password">Password</label>
			  <div class="col-md-5">
				<input id="password" name="password" type="password" placeholder="" class="form-control input-md" required="">
				
			  </div>
			</div>
			
			<div class="form-group"  align="right">
			  <label class="col-md-4 control-label" for="login"></label>
			  <div class="col-md-5">
				<input type="submit" name="lgn" class="btn btn-success " value="Add">
			  </div>
			</div>
			</fieldset>
		</form>
		</div>
		<font color="grey">Already have an acount?</font> <a href="index.php">Login here </a>
		</div>
	</div>

</body>
</html>
<?php 
   $path = $_SERVER['DOCUMENT_ROOT'];
   $path .= "footer.php";
   include_once("footer.php");
?>