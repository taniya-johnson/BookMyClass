<?php
include_once("header.php");
include_once("navbar.php");
?>
<html>
<head>
    <style>
        body {
            background-image: url();
            background-color: white;
        }

        th {
            text-align: center;
        }

        tr {
            height: 30px;
        }

        td {
            padding-top: 5px;
            padding-left: 20px;
            padding-bottom: 5px;
            height: 20px;
        }
    </style>
</head>
<body><br>
<div class="container">
    <?php
    echo "<table width='' class='table table-bordered' border='1' >
            <tr>
                <th>Department</th>
                <th>Faculty</th>
                <th>Action</th>
            </tr>";
    // your database connection
    $host = "localhost";
    $username = "root";
    $password = "";
    $database = "insertion";

    // Create connection
    $conn = new mysqli($host, $username, $password, $database);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $query = "SELECT * FROM faculty";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row['faculty_name'] . "</td>";
            echo "<td>" . $row['designation'] . "</td>";
            echo "<td>
                        <form class='form-horizontal' method='post' action='faclist.php'>
                            <input name='faculty_id' type='hidden' value='" . $row['faculty_id'] . "'>
                            <input type='submit' class='btn btn-danger' name='delete' value='Delete'>
                        </form>
                    </td>";
            echo "</tr>";
        }
    }
    echo "</table>";

    // delete record
    if ($_SERVER['REQUEST_METHOD'] == "POST") {
        echo '<script type="text/javascript">
                      alert("row Successfuly Deleted");
                         location="list.php";
                           </script>';
    }
    if (isset($_POST['faculty_id'])) {
        $faculty_id = $conn->real_escape_string($_POST['faculty_id']);
        $sql = "DELETE FROM faculty WHERE faculty_id='$faculty_id'";
        if ($conn->query($sql) === FALSE) {
            echo "Error deleting record: " . $conn->error;
        }
    }
    ?>
</div>
</body>
</html>

<?php
include_once("footer.php");
?>
