<?php
include_once("header.php");
include_once("navbar.php");
?>

<html>
<head>
    <style>
        body {
            background-image: url();
            background-color: white;
        }

        th {
            text-align: center;
        }

        tr {
            height: 30px;
        }

        td {
            padding-top: 5px;
            padding-left: 20px;
            padding-bottom: 5px;
            height: 20px;
        }
    </style>
</head>
<body>
<br>
<div class="container">
    <body>
    <?php
    echo "<table width='' class='table table-bordered' border='1'>
            <tr>
                <th>Rooms</th>
                <th>Action</th>
            </tr>";

    // your database connection
    $host = "localhost";
    $username = "root";
    $password = "";
    $database = "insertion";

    // select database
    $conn = mysqli_connect($host, $username, $password, $database);
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $query = "SELECT * FROM rooms";
    $result = mysqli_query($conn, $query) or die(mysqli_error($conn));

    while ($row = mysqli_fetch_array($result)) {
        echo "<tr>";
        echo "<td>" . $row['room'] . "</td>";
        echo "<td>
                  <form class='form-horizontal' method='post' action='roomlist.php'>
                      <input name='id' type='hidden' value='" . $row['id'] . "'>
                      <input type='submit' class='btn btn-danger' name='delete' value='Delete'>
                  </form>
              </td>";
        echo "</tr>";
    }
    echo "</table>";

    // delete record
    if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['id'])) {
        $id = mysqli_real_escape_string($conn, $_POST['id']);
        $sql = mysqli_query($conn, "DELETE FROM rooms WHERE id='$id'");
        if ($sql) {
            echo '<script type="text/javascript">
                      alert("Schedule Successfully Deleted");
                      window.location="tablelist.php";
                  </script>';
        } else {
            echo "Error deleting record: " . mysqli_error($conn);
        }
    }
    mysqli_close($conn);
    ?>
    </body>
</div>
</body>
</html>

<?php
$path = $_SERVER['DOCUMENT_ROOT'];
$path .= "footer.php";
include_once("footer.php");
?>
