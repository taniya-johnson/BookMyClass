<?php
session_start();

if (isset($_POST['username']) && isset($_POST['password'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Create connection
    $conn = new mysqli("localhost", "root", "", "insertion");

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare statement
    $stmt = $conn->prepare("SELECT username, password FROM admin WHERE username=?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($dbusername, $dbpassword);
        $stmt->fetch();
        
        // Verify password
        if ($password === $dbpassword) {
            echo '<script type="text/javascript">
                      alert("Welcome User!");
                      location="base.php";
                  </script>';
            $_SESSION['username'] = $username;
        } else {
            echo '<script type="text/javascript">
                      alert("Wrong Password!");
                      location="index.php";
                  </script>';
        }
    } else {
        echo '<script type="text/javascript">
                  alert("That user does not exist!");
                  location="index.php";
              </script>';
    }

    $stmt->close();
    $conn->close();
} else {
    echo '<script type="text/javascript">
              alert("Please enter a username and password!");
              location="tb.php";
          </script>';
}
?>
