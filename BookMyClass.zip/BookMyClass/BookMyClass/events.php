<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "insertion";

$conn = new mysqli($host, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['fetchEvents'])) {
    $events = array();

    $query = "SELECT * FROM addtable";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $events[] = array(
                'title' => $row['subject'],
                'start' => $row['date'] . 'T' . $row['start_time'], // Combine date and time for fullcalendar format
                'end' => $row['date'] . 'T' . $row['end_time'] // Combine date and time for fullcalendar format
            );
        }
    }

    echo json_encode($events);
}

$conn->close();
?>
