<?php
include_once("header.php");
include_once("navbar.php");

$hostname = "localhost";
$username = "root";
$password = "";
$databaseName = "insertion";

// Connect to MySQL database
$connect = mysqli_connect($hostname, $username, $password, $databaseName);

// MySQL select query for rooms
$query4 = "SELECT * FROM `rooms`";
$result4 = mysqli_query($connect, $query4);

// Check if there are any rooms available
if (mysqli_num_rows($result4) > 0) {
    echo "<div class='container'>";
    echo "<h2>Rooms</h2>";
    echo "<table class='table'>";
    echo "<thead><tr><th>ID</th><th>Room</th><th>Date</th></tr></thead>";
    echo "<tbody>";

    // Fetch each row of the result set
    while ($row4 = mysqli_fetch_assoc($result4)) {
        // Display each row's data
        echo "<tr>";
        echo "<td>" . $row4['id'] . "</td>";
        echo "<td>" . $row4['room'] . "</td>";
        // Here you can add the date information, assuming it's available in the same table
        echo "<td>" . date('Y-m-d') . "</td>"; // This assumes you want to display the current date
        echo "</tr>";
    }

    echo "</tbody></table>";
    echo "</div>";
} else {
    echo "No rooms found.";
}

// Close the database connection
mysqli_close($connect);

include_once("footer.php");
?>
